"""
content_based.py
-----------------
Content-Based Filtering recommender.

Idea: represent each movie as a vector built from its genres (via TF-IDF),
then recommend movies whose genre-vectors are most similar (cosine
similarity) to a movie the user already likes. This works even for movies
with very few or zero ratings ("cold start" problem), since it only needs
the item's own metadata.
"""

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class ContentBasedRecommender:
    def __init__(self, movies_df: pd.DataFrame):
        """
        movies_df must have columns: movieId, title, genres
        genres are expected as a '|' separated string, e.g. "Action|Sci-Fi"
        """
        self.movies = movies_df.reset_index(drop=True).copy()

        # Turn "Action|Sci-Fi|Thriller" into "Action Sci-Fi Thriller" so
        # TfidfVectorizer treats each genre as a separate "word" / token.
        self.movies["genres_str"] = (
            self.movies["genres"].str.replace("|", " ", regex=False)
        )

        self.vectorizer = TfidfVectorizer(token_pattern=r"[^\s]+")
        self.tfidf_matrix = self.vectorizer.fit_transform(self.movies["genres_str"])

        # Precompute full similarity matrix (movies x movies)
        self.similarity_matrix = cosine_similarity(self.tfidf_matrix)

        self._title_to_index = {
            title.lower(): idx for idx, title in enumerate(self.movies["title"])
        }

    def _get_index(self, title: str):
        idx = self._title_to_index.get(title.lower())
        if idx is None:
            raise ValueError(f"Movie '{title}' not found in dataset.")
        return idx

    def recommend(self, title: str, top_n: int = 5) -> pd.DataFrame:
        """Return the top_n movies most similar in genre to `title`."""
        idx = self._get_index(title)
        scores = list(enumerate(self.similarity_matrix[idx]))
        # Exclude the movie itself, sort by similarity descending
        scores = [s for s in scores if s[0] != idx]
        scores.sort(key=lambda x: x[1], reverse=True)
        top_scores = scores[:top_n]

        result = self.movies.iloc[[i for i, _ in top_scores]][
            ["movieId", "title", "genres"]
        ].copy()
        result["similarity"] = [round(score, 3) for _, score in top_scores]
        return result.reset_index(drop=True)

    def recommend_for_liked_movies(self, titles: list, top_n: int = 5) -> pd.DataFrame:
        """
        Recommend movies similar to a *list* of movies a user has liked,
        by averaging their genre vectors. Useful when we know several
        movies a user enjoyed rather than just one.
        """
        indices = [self._get_index(t) for t in titles]
        avg_vector = self.tfidf_matrix[indices].mean(axis=0)
        # cosine_similarity expects a 2D array
        import numpy as np
        avg_vector = np.asarray(avg_vector)
        sims = cosine_similarity(avg_vector, self.tfidf_matrix)[0]

        scores = [(i, s) for i, s in enumerate(sims) if i not in indices]
        scores.sort(key=lambda x: x[1], reverse=True)
        top_scores = scores[:top_n]

        result = self.movies.iloc[[i for i, _ in top_scores]][
            ["movieId", "title", "genres"]
        ].copy()
        result["similarity"] = [round(score, 3) for _, score in top_scores]
        return result.reset_index(drop=True)
