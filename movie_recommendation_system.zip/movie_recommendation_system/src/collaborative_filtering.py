"""
collaborative_filtering.py
---------------------------
Collaborative Filtering recommenders.

Idea: ignore movie content entirely and instead learn from the
user-item rating matrix itself: "users who rated things similarly to
you in the past will probably agree with you in the future."

Three approaches are implemented:
  1. User-Based CF   - find users similar to the target user, recommend
                        what THEY liked that the target user hasn't seen.
  2. Item-Based CF    - find movies similar to ones the target user rated
                        highly, based on rating patterns (not genres).
  3. Matrix Factorization (SVD) - learn latent factors for users and
                        movies and predict missing ratings.
"""

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import TruncatedSVD


class CollaborativeFilteringRecommender:
    def __init__(self, ratings_df: pd.DataFrame, movies_df: pd.DataFrame):
        """
        ratings_df must have columns: userId, movieId, rating
        movies_df must have columns: movieId, title
        """
        self.ratings = ratings_df.copy()
        self.movies = movies_df.copy()

        # Build the user-item ratings matrix (rows=users, cols=movies)
        self.user_item_matrix = self.ratings.pivot_table(
            index="userId", columns="movieId", values="rating"
        )

        # Filled-with-zero version, needed for similarity computations
        self._filled_matrix = self.user_item_matrix.fillna(0)

        self.user_similarity = pd.DataFrame(
            cosine_similarity(self._filled_matrix),
            index=self.user_item_matrix.index,
            columns=self.user_item_matrix.index,
        )

        self.item_similarity = pd.DataFrame(
            cosine_similarity(self._filled_matrix.T),
            index=self.user_item_matrix.columns,
            columns=self.user_item_matrix.columns,
        )

        self._movie_titles = self.movies.set_index("movieId")["title"]

    # ------------------------------------------------------------------
    # 1. USER-BASED COLLABORATIVE FILTERING
    # ------------------------------------------------------------------
    def recommend_user_based(self, user_id: int, top_n: int = 5, k_neighbors: int = 5) -> pd.DataFrame:
        if user_id not in self.user_item_matrix.index:
            raise ValueError(f"User {user_id} not found in ratings data.")

        # Most similar users to this one (excluding themselves)
        similar_users = (
            self.user_similarity[user_id]
            .drop(index=user_id)
            .sort_values(ascending=False)
            .head(k_neighbors)
        )

        already_rated = set(
            self.ratings.loc[self.ratings.userId == user_id, "movieId"]
        )

        # Weighted average of neighbors' ratings, weighted by similarity
        weighted_scores = {}
        weight_sums = {}
        for neighbor_id, sim in similar_users.items():
            if sim <= 0:
                continue
            neighbor_ratings = self.user_item_matrix.loc[neighbor_id]
            for movie_id, rating in neighbor_ratings.dropna().items():
                if movie_id in already_rated:
                    continue
                weighted_scores[movie_id] = weighted_scores.get(movie_id, 0) + sim * rating
                weight_sums[movie_id] = weight_sums.get(movie_id, 0) + sim

        predicted = {
            movie_id: weighted_scores[movie_id] / weight_sums[movie_id]
            for movie_id in weighted_scores
            if weight_sums[movie_id] > 0
        }

        return self._build_result(predicted, top_n)

    # ------------------------------------------------------------------
    # 2. ITEM-BASED COLLABORATIVE FILTERING
    # ------------------------------------------------------------------
    def recommend_item_based(self, user_id: int, top_n: int = 5) -> pd.DataFrame:
        if user_id not in self.user_item_matrix.index:
            raise ValueError(f"User {user_id} not found in ratings data.")

        user_ratings = self.user_item_matrix.loc[user_id].dropna()
        already_rated = set(user_ratings.index)

        scores = {}
        weight_sums = {}
        for rated_movie, rating in user_ratings.items():
            sims = self.item_similarity[rated_movie]
            for candidate_movie, sim in sims.items():
                if candidate_movie in already_rated or sim <= 0:
                    continue
                scores[candidate_movie] = scores.get(candidate_movie, 0) + sim * rating
                weight_sums[candidate_movie] = weight_sums.get(candidate_movie, 0) + sim

        predicted = {
            movie_id: scores[movie_id] / weight_sums[movie_id]
            for movie_id in scores
            if weight_sums[movie_id] > 0
        }

        return self._build_result(predicted, top_n)

    # ------------------------------------------------------------------
    # 3. MATRIX FACTORIZATION (SVD)
    # ------------------------------------------------------------------
    def recommend_svd(self, user_id: int, top_n: int = 5, n_factors: int = 10) -> pd.DataFrame:
        if user_id not in self.user_item_matrix.index:
            raise ValueError(f"User {user_id} not found in ratings data.")

        n_factors = min(n_factors, min(self._filled_matrix.shape) - 1)
        n_factors = max(n_factors, 1)

        svd = TruncatedSVD(n_components=n_factors, random_state=42)
        user_factors = svd.fit_transform(self._filled_matrix)
        item_factors = svd.components_

        predicted_matrix = np.dot(user_factors, item_factors)
        predicted_df = pd.DataFrame(
            predicted_matrix,
            index=self.user_item_matrix.index,
            columns=self.user_item_matrix.columns,
        )

        user_predictions = predicted_df.loc[user_id]
        already_rated = set(
            self.ratings.loc[self.ratings.userId == user_id, "movieId"]
        )
        predicted = {
            movie_id: score
            for movie_id, score in user_predictions.items()
            if movie_id not in already_rated
        }

        return self._build_result(predicted, top_n)

    # ------------------------------------------------------------------
    def _build_result(self, predicted_scores: dict, top_n: int) -> pd.DataFrame:
        if not predicted_scores:
            return pd.DataFrame(columns=["movieId", "title", "predicted_rating"])

        top_items = sorted(predicted_scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
        rows = [
            {
                "movieId": movie_id,
                "title": self._movie_titles.get(movie_id, "Unknown"),
                "predicted_rating": round(score, 2),
            }
            for movie_id, score in top_items
        ]
        return pd.DataFrame(rows)
