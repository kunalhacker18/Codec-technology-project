"""
hybrid.py
---------
Combines Content-Based and Collaborative Filtering.

Why hybrid? Content-based filtering handles the "cold start" problem
(new movies with no ratings yet) but tends to over-specialize (only
ever recommends similar genres). Collaborative filtering captures
patterns content-based filtering can't see (e.g. "people who liked
weird sci-fi also liked this comedy") but fails for new items/users
with no rating history. Blending both gives more robust results.
"""

import pandas as pd


class HybridRecommender:
    def __init__(self, content_recommender, collaborative_recommender):
        self.content = content_recommender
        self.collab = collaborative_recommender

    def recommend(self, user_id: int, liked_title: str, top_n: int = 5,
                   content_weight: float = 0.5) -> pd.DataFrame:
        """
        Blend item-based collaborative filtering with content-based
        similarity to `liked_title`. content_weight in [0, 1] controls
        how much weight content-based similarity gets vs collaborative
        filtering's predicted rating.
        """
        content_results = self.content.recommend(liked_title, top_n=20)
        collab_results = self.collab.recommend_item_based(user_id, top_n=20)

        # Normalize each score column to 0-1 so they're comparable
        def normalize(series):
            if series.max() == series.min():
                return series * 0 + 1.0
            return (series - series.min()) / (series.max() - series.min())

        content_results = content_results.set_index("movieId")
        collab_results = collab_results.set_index("movieId")

        content_results["norm_score"] = normalize(content_results["similarity"])
        collab_results["norm_score"] = normalize(collab_results["predicted_rating"])

        all_ids = set(content_results.index) | set(collab_results.index)
        blended = []
        for movie_id in all_ids:
            c_score = content_results["norm_score"].get(movie_id, 0)
            cf_score = collab_results["norm_score"].get(movie_id, 0)
            final_score = content_weight * c_score + (1 - content_weight) * cf_score
            title = (
                content_results["title"].get(movie_id)
                if movie_id in content_results.index
                else collab_results["title"].get(movie_id)
            )
            blended.append({"movieId": movie_id, "title": title, "hybrid_score": round(final_score, 3)})

        result = pd.DataFrame(blended).sort_values("hybrid_score", ascending=False)
        return result.head(top_n).reset_index(drop=True)
