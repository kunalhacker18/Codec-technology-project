"""
Generates data/ratings.csv -- a synthetic but realistic user-movie ratings
dataset. Each synthetic user has 1-2 favorite genres, and rates movies
higher if those genres are present (with noise), producing a dataset where
collaborative filtering has real signal to find.

Run once: python generate_ratings.py
"""
import csv
import random

random.seed(42)

GENRE_POOL = [
    "Action", "Sci-Fi", "Thriller", "Mystery", "Adventure", "Drama",
    "Crime", "Romance", "Comedy", "Musical", "Animation", "Family",
    "Fantasy", "Horror", "Biography", "History", "War", "Music"
]

with open("data/movies.csv") as f:
    reader = csv.DictReader(f)
    movies = list(reader)
    for m in movies:
        m["genres"] = m["genres"].split("|")

NUM_USERS = 25
rows = [("userId", "movieId", "rating")]

for user_id in range(1, NUM_USERS + 1):
    fav_genres = set(random.sample(GENRE_POOL, k=random.choice([1, 2])))
    # each user rates a random subset of 12-25 movies
    n_ratings = random.randint(12, 25)
    rated_movies = random.sample(movies, k=n_ratings)
    for m in rated_movies:
        overlap = len(fav_genres.intersection(m["genres"]))
        base = 2.5 + overlap * 1.2          # more overlap -> higher base rating
        noise = random.uniform(-1.0, 1.0)
        rating = max(1.0, min(5.0, base + noise))
        rating = round(rating * 2) / 2       # round to nearest 0.5
        rows.append((user_id, m["movieId"], rating))

with open("data/ratings.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(rows)

print(f"Generated {len(rows) - 1} ratings for {NUM_USERS} users -> data/ratings.csv")
