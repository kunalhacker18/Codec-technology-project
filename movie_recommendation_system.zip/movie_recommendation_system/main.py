"""
main.py
-------
Demo / entry point for the Movie Recommendation System.

Run with no arguments for a full demo of every technique:
    python main.py

Or run interactively:
    python main.py --interactive
"""

import argparse
import os
import sys

import pandas as pd

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from content_based import ContentBasedRecommender
from collaborative_filtering import CollaborativeFilteringRecommender
from hybrid import HybridRecommender

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


def load_data():
    movies = pd.read_csv(os.path.join(DATA_DIR, "movies.csv"))
    ratings = pd.read_csv(os.path.join(DATA_DIR, "ratings.csv"))
    return movies, ratings


def print_table(title: str, df: pd.DataFrame):
    print(f"\n{title}")
    print("-" * len(title))
    if df.empty:
        print("(no recommendations found)")
    else:
        print(df.to_string(index=False))


def run_demo():
    movies, ratings = load_data()

    content_model = ContentBasedRecommender(movies)
    collab_model = CollaborativeFilteringRecommender(ratings, movies)
    hybrid_model = HybridRecommender(content_model, collab_model)

    demo_movie = "Inception"
    demo_user = 1

    print("=" * 60)
    print("MOVIE RECOMMENDATION SYSTEM - DEMO")
    print("=" * 60)
    print(f"\nDataset: {len(movies)} movies, {ratings['userId'].nunique()} users, "
          f"{len(ratings)} ratings")

    # 1. Content-based
    print_table(
        f"1) CONTENT-BASED -- movies similar to '{demo_movie}' (by genre)",
        content_model.recommend(demo_movie, top_n=5),
    )

    # 2. Content-based from multiple liked movies
    liked = ["The Dark Knight", "John Wick"]
    print_table(
        f"2) CONTENT-BASED -- movies similar to liked list {liked}",
        content_model.recommend_for_liked_movies(liked, top_n=5),
    )

    # 3. User-based collaborative filtering
    print_table(
        f"3) COLLABORATIVE (USER-BASED) -- recommendations for User {demo_user}",
        collab_model.recommend_user_based(demo_user, top_n=5),
    )

    # 4. Item-based collaborative filtering
    print_table(
        f"4) COLLABORATIVE (ITEM-BASED) -- recommendations for User {demo_user}",
        collab_model.recommend_item_based(demo_user, top_n=5),
    )

    # 5. Matrix factorization (SVD)
    print_table(
        f"5) COLLABORATIVE (SVD / MATRIX FACTORIZATION) -- recommendations for User {demo_user}",
        collab_model.recommend_svd(demo_user, top_n=5),
    )

    # 6. Hybrid
    print_table(
        f"6) HYBRID -- blending content-based + collaborative for User {demo_user} "
        f"(liked '{demo_movie}')",
        hybrid_model.recommend(demo_user, demo_movie, top_n=5),
    )

    print("\nDone. See README.md for an explanation of each technique.\n")


def run_interactive():
    movies, ratings = load_data()
    content_model = ContentBasedRecommender(movies)
    collab_model = CollaborativeFilteringRecommender(ratings, movies)

    print("Available movies (sample):")
    print(movies["title"].sample(10, random_state=1).to_string(index=False))

    choice = input("\nChoose mode: [1] By movie title  [2] By user ID > ").strip()

    if choice == "1":
        title = input("Enter a movie title you like: ").strip()
        try:
            print_table(f"Movies similar to '{title}'", content_model.recommend(title, top_n=8))
        except ValueError as e:
            print(e)
    elif choice == "2":
        try:
            user_id = int(input(f"Enter a user ID (1-{ratings.userId.max()}): ").strip())
            print_table(
                f"Recommendations for User {user_id}",
                collab_model.recommend_item_based(user_id, top_n=8),
            )
        except (ValueError, KeyError) as e:
            print(f"Invalid input: {e}")
    else:
        print("Invalid choice.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Movie Recommendation System")
    parser.add_argument("--interactive", action="store_true", help="Run in interactive mode")
    args = parser.parse_args()

    if args.interactive:
        run_interactive()
    else:
        run_demo()
