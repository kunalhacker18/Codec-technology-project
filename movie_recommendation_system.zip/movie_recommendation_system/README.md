# Movie Recommendation System

A Python implementation of a movie recommender that combines **content-based
filtering** and **collaborative filtering**, plus a **hybrid** model that
blends the two. Built as a certificate project to demonstrate the core
techniques behind real-world recommendation engines (think Netflix,
Letterboxd, or IMDb's "More Like This").

## Features

- **Content-Based Filtering** — recommends movies with similar genres using
  TF-IDF vectorization and cosine similarity. Works even for movies with no
  ratings yet (solves the "cold start" problem for new items).
- **Collaborative Filtering** — three variants:
  - *User-Based*: finds users with similar taste and recommends what they liked.
  - *Item-Based*: finds movies that tend to be rated similarly by the same users.
  - *Matrix Factorization (SVD)*: learns latent "taste factors" for users and
    movies and predicts missing ratings.
- **Hybrid Recommender** — blends content-based and item-based collaborative
  scores into a single ranked list, with a tunable weight.
- A synthetic but realistic dataset (50 movies, 25 users, ~470 ratings) where
  each simulated user has genre preferences, so the recommendations are
  actually meaningful, not random.

## Project Structure

```
movie_recommendation_system/
├── data/
│   ├── movies.csv              # movieId, title, genres
│   └── ratings.csv             # userId, movieId, rating
├── src/
│   ├── content_based.py        # Content-Based Filtering
│   ├── collaborative_filtering.py  # User-based, item-based, SVD
│   └── hybrid.py                # Hybrid blend of the above
├── generate_ratings.py         # Script used to create the synthetic ratings
├── main.py                     # CLI entry point / demo
├── requirements.txt
└── README.md
```

## How It Works

### 1. Content-Based Filtering
Each movie's genres (e.g. `"Action|Sci-Fi|Thriller"`) are converted into a
TF-IDF vector, treating each genre as a token. Cosine similarity between
these vectors tells us how "alike" two movies are. Given a movie a user
likes, we return the most similar movies by genre profile. We can also
average the vectors of several liked movies to recommend based on a
person's overall taste rather than a single title.

**Strength:** works instantly for brand-new movies/users.
**Weakness:** tends to recommend only within the same genres — it can't
discover "people who liked X also unexpectedly liked Y" patterns.

### 2. Collaborative Filtering
Built from the user × movie ratings matrix (most cells empty, since no user
rates every movie):

- **User-Based CF** finds the `k` most similar users (by cosine similarity
  of their rating vectors) and recommends movies those neighbors rated
  highly that the target user hasn't seen yet, weighted by similarity.
- **Item-Based CF** flips this: for movies the user already rated highly,
  it finds other movies with a similar *rating pattern* across all users
  (not similar genres — purely behavioral) and recommends those.
- **Matrix Factorization (SVD)** decomposes the sparse ratings matrix into
  lower-dimensional user-factor and item-factor matrices using
  `TruncatedSVD`, then reconstructs predicted ratings for every
  user-movie pair, including unseen ones.

**Strength:** can surface non-obvious cross-genre recommendations purely
from behavior patterns.
**Weakness:** needs enough rating data to work — fails for brand-new users
or movies ("cold start").

### 3. Hybrid Recommender
Combines content-based similarity scores and item-based collaborative
scores (each normalized to a 0–1 range) into one weighted ranking, taking
advantage of both approaches' strengths.

## Installation

```bash
pip install -r requirements.txt
```

(Optional) regenerate the synthetic ratings dataset:

```bash
python generate_ratings.py
```

## Usage

Run the full demo, which exercises every technique against the sample data:

```bash
python main.py
```

Run in interactive mode to query the system yourself:

```bash
python main.py --interactive
```

You'll be asked to either enter a movie title (for content-based
recommendations) or a user ID 1–25 (for collaborative recommendations).

### Using it in your own code

```python
import pandas as pd
from src.content_based import ContentBasedRecommender
from src.collaborative_filtering import CollaborativeFilteringRecommender
from src.hybrid import HybridRecommender

movies = pd.read_csv("data/movies.csv")
ratings = pd.read_csv("data/ratings.csv")

content_model = ContentBasedRecommender(movies)
print(content_model.recommend("Inception", top_n=5))

collab_model = CollaborativeFilteringRecommender(ratings, movies)
print(collab_model.recommend_item_based(user_id=1, top_n=5))

hybrid_model = HybridRecommender(content_model, collab_model)
print(hybrid_model.recommend(user_id=1, liked_title="Inception", top_n=5))
```

## Using Your Own Data

Replace `data/movies.csv` and `data/ratings.csv` with your own, keeping the
same columns (`movieId,title,genres` and `userId,movieId,rating`). Everything
else works unmodified — this also works well with the public
[MovieLens dataset](https://grouplens.org/datasets/movielens/) if you want to
scale up to thousands of real movies and ratings.

## Possible Extensions

- Evaluate accuracy with train/test splits and metrics like RMSE or
  precision@k.
- Add implicit feedback (watch history, clicks) instead of only explicit
  star ratings.
- Incorporate additional metadata (cast, director, plot keywords, release
  year) into the content-based vectors.
- Swap `TruncatedSVD` for a proper matrix-factorization library (e.g.
  `surprise`'s SVD with bias terms) for better predictive accuracy.
- Wrap the recommenders in a small Flask/FastAPI web app for a live demo UI.
